package program1;

public class Library {
    public static void CreateMatrix(String path, String hasil) {
        java.io.File file = new java.io.File(path);

        try (java.util.Scanner input = new java.util.Scanner(file);) {
            int typeInput = input.nextInt();

            // GEO
            if(typeInput == 1) {
                int n = input.nextInt();
                double[][] a = new double[n][2];
                for(int i = 0; i < n; i++) {
                    input.nextInt();
                    a[i][0] = input.nextDouble();
                    a[i][1] = input.nextDouble();
                }

                java.io.File file1 = new java.io.File(hasil);
                java.io.PrintWriter output = new java.io.PrintWriter(file1);

                output.println(n);
                for(int i = 0; i < a.length; i++) {
                    for(int j = 0; j < a.length; j++) {
                        if(i != j) {
                            double xi = a[i][0];
                            double yi = a[i][1];
                            double xj = a[j][0];
                            double yj = a[j][1];
                            double pi = 3.141592;
                            double deg, min;

                            deg = (int)xi;
                            min = xi - deg;
                            double latitudei = pi*(deg+5.0*min/3.0)/180.0;
                            deg = (int)yi;
                            min = yi - deg;
                            double longitudei = pi*(deg+5.0*min/3.0)/180.0;

                            deg = (int)xj;
                            min = xj - deg;
                            double latitudej = pi*(deg+5.0*min/3.0)/180.0;
                            deg = (int)yj;
                            min = yj - deg;
                            double longitudej = pi*(deg+5.0*min/3.0)/180.0;

                            double RRR = 6378.388;
                            double q1 = Math.cos(longitudei - longitudej);
                            double q2 = Math.cos(latitudei - latitudej);
                            double q3 = Math.cos(latitudei + latitudej);

                            double Dij = RRR*Math.acos(0.5*((1.0+q1)*q2 - (1.0-q1)*q3))+1.0;

                            int dij = (int)Dij;

                            output.print(dij + "\t");
                        }
                        else {
                            output.print("0\t");
                        }
                    }
                    output.println("");
                }
                output.close();
            }

            // LOWER_DIAG_ROW
            else if(typeInput == 2) {
                int n = input.nextInt();
                int[][] a = new int[n][n];
                for(int i = 0; i < n; i++) {
                    for(int j = 0; j <= i; j++) {
                        a[i][j] = input.nextInt();
                        a[j][i] = a[i][j];
                    }
                }

                java.io.File file1 = new java.io.File(hasil);
                java.io.PrintWriter output = new java.io.PrintWriter(file1);

                output.println(n);
                for(int i = 0; i < a.length; i++) {
                    for(int j = 0; j < a.length; j++) {
                        int distance = a[i][j];
                        output.print(distance + "\t");
                    }
                    output.println("");
                }
                output.close();
            }

            // UPPER_ROW
            else if(typeInput == 3) {
                int n = input.nextInt();
                int[][] a = new int[n][n];
                for(int i = 0; i < n-1; i++) {
                    for(int j = i+1; j < n; j++) {
                        a[i][j] = input.nextInt();
                        a[j][i] = a[i][j];
                    }
                }

                java.io.File file1 = new java.io.File(hasil);
                java.io.PrintWriter output = new java.io.PrintWriter(file1);

                output.println(n);
                for(int i = 0; i < a.length; i++) {
                    for(int j = 0; j < a.length; j++) {
                        int distance = a[i][j];
                        output.print(distance + "\t");
                    }
                    output.println("");
                }
                output.close();
            }

            // FULL_MATRIX
            else if(typeInput == 4) {
                int n = input.nextInt();
                int[][] a = new int[n][n];
                for(int i = 0; i < n; i++) {
                    for(int j = 0; j < n; j++) {
                        a[i][j] = input.nextInt();
                    }
                }

                java.io.File file1 = new java.io.File(hasil);
                java.io.PrintWriter output = new java.io.PrintWriter(file1);

                output.println(n);
                for(int i = 0; i < a.length; i++) {
                    for(int j = 0; j < a.length; j++) {
                        int distance = a[i][j];
                        output.print(distance + "\t");
                    }
                    output.println("");
                }
                output.close();
            }

            // ATT
            else if(typeInput == 5) {
                int n = input.nextInt();
                double[][] a = new double[n][2];
                for(int i = 0; i < n; i++) {
                    input.nextInt();
                    a[i][0] = input.nextDouble();
                    a[i][1] = input.nextDouble();
                }

                java.io.File file1 = new java.io.File(hasil);
                java.io.PrintWriter output = new java.io.PrintWriter(file1);

                output.println(n);
                for(int i = 0; i < a.length; i++) {
                    for(int j = 0; j < a.length; j++) {
                        if(i != j) {
                            double xd = a[i][0] - a[j][0];
                            double yd = a[i][1] - a[j][1];
                            double rij = Math.sqrt((xd*xd + yd*yd)/10.0);
                            int tij = (int)rij;
                            int dij;
                            if((double)tij < rij) {
                                dij = tij+1;
                            }
                            else {
                                dij = tij;
                            }
                            output.print(dij + "\t");
                        }
                        else {
                            output.print("0\t");
                        }
                    }
                    output.println("");
                }
                output.close();
            }
            
            // EUC_2D
            else if(typeInput == 6) {
                int n = input.nextInt();
                double[][] a = new double[n][2];
                for(int i = 0; i < n; i++) {
                    input.nextInt();
                    a[i][0] = input.nextDouble();
                    a[i][1] = input.nextDouble();
                }

                java.io.File file1 = new java.io.File(hasil);
                java.io.PrintWriter output = new java.io.PrintWriter(file1);

                output.println(n);
                for(int i = 0; i < a.length; i++) {
                    for(int j = 0; j < a.length; j++) {
                        if(i != j) {
                            double xd = a[i][0] - a[j][0];
                            double yd = a[i][1] - a[j][1];
                            double distance = Math.sqrt(xd*xd + yd*yd) + 0.5;
                            int dij = (int)distance;
                            output.print(dij + "\t");
                        }
                        else {
                            output.print("0\t");
                        }
                    }
                    output.println("");
                }
                output.close();
            }        
            
            // UPPER_DIAG_ROW
            else if(typeInput == 7) {
                int n = input.nextInt();
                int[][] a = new int[n][n];
                for(int i = 0; i < n; i++) {
                    for(int j = i; j < n; j++) {
                        a[i][j] = input.nextInt();
                        a[j][i] = a[i][j];
                    }
                }

                java.io.File file1 = new java.io.File(hasil);
                java.io.PrintWriter output = new java.io.PrintWriter(file1);

                output.println(n);
                for(int i = 0; i < a.length; i++) {
                    for(int j = 0; j < a.length; j++) {
                        int distance = a[i][j];
                        output.print(distance + "\t");
                    }
                    output.println("");
                }
                output.close();
            }
        }
        catch (java.io.IOException e) {
            e.printStackTrace();
        }
    }
}