package program1;

public class Program1 {

    public static void main(String[] args) {
        String file[] = {
            //nama file             //index
            "1.burma14.tsp.txt",    //0
            "2.ulysses16.tsp.txt",  //1
            "3.gr17.tsp.txt",       //2
            "4.gr21.tsp.txt",       //3
            "5.ulysses22.tsp.txt",  //4
            "6.gr24.tsp.txt",       //5
            "7.fri26.tsp.txt",      //6
            "8.bayg29.tsp.txt",     //7
            "9.bays29.tsp.txt",     //8
            "10.dantzig42.tsp.txt", //9
            "11.swiss42.tsp.txt",   //10
            "12.att48.tsp.txt",     //11
            "13.gr48.tsp.txt",      //12
            "14.hk48.tsp.txt",      //13
            "15.eil51.tsp.txt",     //14
            "16.berlin52.tsp.txt",  //15
            "17.brazil58.tsp.txt",  //16
            "18.st70.tsp.txt",      //17
            "19.eil76.tsp.txt",     //18
            "20.pr76.tsp.txt",      //19
            "21.gr96.tsp.txt",      //20
            "22.rat99.tsp.txt",     //21
            "23.kroA100.tsp.txt",   //22
            "24.kroB100.tsp.txt",   //23
            "25.kroC100.tsp.txt",   //24
            "26.kroD100.tsp.txt",   //25
            "27.kroE100.tsp.txt",   //26
            "28.rd100.tsp.txt",     //27
            "29.eil101.tsp.txt",    //28
            "30.lin105.tsp.txt"    //29
        };
        
        for(int i = 0; i < file.length; i++) {
            String path = "D:\\2c. Data\\1. TSP\\1. Symmetric TSP\\2. Data Setelah Disederhanakan\\" + file[i];
            Library.CreateMatrix(path, file[i]);
        }
    }
}